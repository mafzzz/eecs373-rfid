#ifndef top_HW_PLATFORM_H_
#define top_HW_PLATFORM_H_
/*****************************************************************************
*
*Created by Actel SmartDesign  Tue Apr 05 15:14:27 2011
*
*Memory map specification for peripherals in top
*/

/*-----------------------------------------------------------------------------
* mss_core_0 subsystem memory map
* Master(s) for this subsystem: mss_core_0 
*---------------------------------------------------------------------------*/
#define DISP_UART                       0x00000000U
#define RFID_UART                       0x00000100U
#define BARCODE_UART                    0x00000200U


#endif /* top_HW_PLATFORM_H_*/
