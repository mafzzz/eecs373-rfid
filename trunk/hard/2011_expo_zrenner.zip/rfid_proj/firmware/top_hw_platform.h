#ifndef top_HW_PLATFORM_H_
#define top_HW_PLATFORM_H_
/*****************************************************************************
*
*Created by Actel SmartDesign  Thu Apr 14 03:45:23 2011
*
*Memory map specification for peripherals in top
*/

/*-----------------------------------------------------------------------------
* mss_core_0 subsystem memory map
* Master(s) for this subsystem: mss_core_0 
*---------------------------------------------------------------------------*/
#define DISP_UART                       0x40050000U
#define RFID_UART                       0x40050100U
#define BARCODE_UART                    0x40050200U
#define ROW_1_RAG_WRP_0                 0x40050300U


#endif /* top_HW_PLATFORM_H_*/
